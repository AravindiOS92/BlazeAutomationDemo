//
//  LightCollectionViewCell.swift
//  BlazeDemo
//
//  Created by System Test on 20/02/19.
//  Copyright © 2019 System Test. All rights reserved.
//

import UIKit

class LightCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var lightIMG: UIImageView!
    @IBOutlet weak var titleLBL: UILabel!
    @IBOutlet weak var bgView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        bgView.layer.borderWidth = 0.5
        bgView.layer.borderColor = UIColor.lightGray.cgColor
        
        bgView.layer.cornerRadius = 9.0
        if #available(iOS 11.0, *) {
            bgView.layer.maskedCorners = [.layerMinXMinYCorner,.layerMaxXMinYCorner,.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        } else {
            // Fallback on earlier versions
        }
        
        
    }
    
}
