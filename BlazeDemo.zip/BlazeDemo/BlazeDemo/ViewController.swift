//
//  ViewController.swift
//  BlazeDemo
//
//  Created by System Test on 20/02/19.
//  Copyright © 2019 System Test. All rights reserved.
//

import UIKit


class ViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var opacityBGView: UIView!
    
    
    
    var performanceLighArray = ["Hue","Main  Lights","Bright","Hue","Main  Lights","Bright"]
    var imgArray = ["light1","light2","light3"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       
        
        collectionView.reloadData()
//        opacityBGView?.backgroundColor = UIColor(white: 1, alpha: 0.8)
//        collectionView.backgroundColor = UIColor(white: 1, alpha: 0.8)
        self.collectionView.isPagingEnabled = true
        
//        let blurEffect = UIBlurEffect(style: .dark)
//        let blurredEffectView = UIVisualEffectView(effect: blurEffect)
//        blurredEffectView.frame = opacityBGView.bounds
//        opacityBGView.addSubview(blurredEffectView)
        //collectionView.addSubview(blurredEffectView)
        //collectionView.backgroundView?.addSubview(blurredEffectView)
        
        
        

    }
    
    //CollectionVIew Delegate
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        print(performanceLighArray.count)
        return performanceLighArray.count
       
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
            let identifier = "LightCollectionViewCell"
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath) as! LightCollectionViewCell
        
        cell.titleLBL.text = performanceLighArray[indexPath.row]
       // cell.lightIMG = UIImage
        
        
           
            
            return cell
            
       
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
       
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let controller = storyboard.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        controller.selectdLight = performanceLighArray[indexPath.row]
        print(controller.selectdLight)

        
        self.navigationController?.pushViewController(controller, animated: true)
           // present(controller, animated: true, completion: nil)
        
        
        
    }
 



}

