//
//  DetailViewController.swift
//  BlazeDemo
//
//  Created by System Test on 20/02/19.
//  Copyright © 2019 System Test. All rights reserved.
//

import UIKit
import CoreData
import ChromaColorPicker
import CTShowcase

class DetailViewController: UIViewController {
    
    @IBOutlet var navBTN: UIButton!
    
    @IBOutlet var switchBTN: UISwitch!
    

    var userArr = NSMutableArray()
    
    var switchData = "false"
    var colorData = ""
    let showcase = CTShowcaseView(title: "", message: "", key: nil) { () -> Void in
        print("dismissed")
    }
    
    @IBOutlet var colorDisplayView: UIView!
    var colorPicker: ChromaColorPicker!
    
    var selectdLight:String!
    
    
    
    var selectedColor: UIColor = UIColor.white
    var gradient = CAGradientLayer()
    @IBOutlet weak var lightRayView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()

        
   
        
        navBTN.setTitle("  \(selectdLight!)", for: .normal)
        
        /* Calculate relative size and origin in bounds */
        let pickerSize = CGSize(width: colorDisplayView.bounds.width*0.6, height: colorDisplayView.bounds.width*0.6)
        let pickerOrigin = CGPoint(x: colorDisplayView.bounds.midX - pickerSize.width/2, y: colorDisplayView.bounds.midY - pickerSize.height/2)
        
        /* Create Color Picker */
        colorPicker = ChromaColorPicker(frame: CGRect(origin: pickerOrigin, size: pickerSize))
        colorPicker.delegate = self as ChromaColorPickerDelegate
        
        /* Customize the view (optional) */
        colorPicker.padding = 10
        colorPicker.stroke = 3 //stroke of the rainbow circle
        colorPicker.currentAngle = Float.pi
        
        /* Customize for grayscale (optional) */
        colorPicker.supportsShadesOfGray = true // false by default
        //colorPicker.colorToggleButton.grayColorGradientLayer.colors = [UIColor.lightGray.cgColor, UIColor.gray.cgColor] // You can also override gradient colors
        
        
        colorPicker.hexLabel.textColor = UIColor.white
        
        /* Don't want an element like the shade slider? Just hide it: */
        //colorPicker.shadeSlider.hidden = true
        
        self.colorDisplayView.addSubview(colorPicker)
        
 
        retrieveData()
  
       
        
        
    }
    
   
    
    @IBAction func switchBTNAction(_ sender: UISwitch) {
        print(sender.isOn)
        
        if sender.isOn == true
        {
           lightRayView.isHidden = false
            
            switchData = "true"
            
         
            let highlighter = CTDynamicGlowHighlighter()
            highlighter.highlightColor = UIColor.yellow
            highlighter.animDuration = 0.5
            highlighter.glowSize = 5
            highlighter.maxOffset = 10
            
            showcase.highlighter = highlighter
            showcase.setup(for: lightRayView)
            showcase.show()

        
        }else
        {
            lightRayView.isHidden = true
            switchData = "false"
        }
        coreDate()
       
    }
    
    //Core Date
    func coreDate()
    {
        
        
        let appDelegate2 = UIApplication.shared.delegate as! AppDelegate
        let context2 = appDelegate2.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "User", in: context2)
        let newUser = NSManagedObject(entity: entity!, insertInto: context2)
        newUser.setValue(appDelegate2.colorValue!, forKey: "colorValue")
        newUser.setValue(switchData, forKey: "switchON")
        
        do{
            try context2.save()
        }catch{
            print(error.localizedDescription)
        }
        
        
    }
    
    
    func retrieveData() {
        
        let appDelegate4 = UIApplication.shared.delegate as! AppDelegate
        let context4 = appDelegate4.persistentContainer.viewContext
        let req = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        
        req.returnsObjectsAsFaults = false
        do{
            let result = try context4.fetch(req)
            print(result)
            for data in result as! [NSManagedObject]
            {
                userArr.add(data)
            }
            
            
            let dataNewColor = (userArr.lastObject as AnyObject).value(forKey: "colorValue")
            let dataNewSwitch = (userArr.lastObject as AnyObject).value(forKey: "switchON")
            
            var checkSwitch = dataNewSwitch!
            var checkCOlorCode = dataNewColor!
            
            print("Color Code \(dataNewColor!)")
            print("Switch Value \(dataNewSwitch!)")
            
            if checkSwitch as! String == "true"
            {
                switchBTN.setOn(true, animated: false)
                
            }else{
                switchBTN.setOn(false, animated: false)
            }
            
            if !(dataNewColor! as! String).isEmpty
            {
                self.lightRayView.backgroundColor = UIColor().HexToColor(hexString: checkCOlorCode as! String, alpha: 1.0)
                
                let highlighter = CTDynamicGlowHighlighter()
                highlighter.highlightColor = UIColor().HexToColor(hexString: checkCOlorCode as! String, alpha: 1.0)
                highlighter.animDuration = 0.5
                highlighter.glowSize = 5
                highlighter.maxOffset = 10
                
                showcase.highlighter = highlighter
                showcase.setup(for: lightRayView)
                showcase.show()
            }else{
                print("Empty Data")
            }
            
        
            
          
        }catch
        {
            print(error.localizedDescription)
            
        }
        
        
        
       
    }
    
    
    
    
    

    
    @IBAction func dismissView(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
     //AlertView
     func displayMyAlertMessage(userMessage: String)
     {
        let myAlert = UIAlertController(title: "", message: userMessage, preferredStyle: UIAlertController.Style.alert)
        let okAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler:nil)
     
     myAlert.addAction(okAction)
     self.present(myAlert, animated: true, completion: nil)
     
     }
     
 

    
    
    
}
extension DetailViewController: ChromaColorPickerDelegate{
    func colorPickerDidChooseColor(_ colorPicker: ChromaColorPicker, color: UIColor) {
        //Set color for the display view
       // lightRayView.backgroundColor = color
        
         let appDelegate3 = UIApplication.shared.delegate as! AppDelegate
        
        appDelegate3.colorValue = colorPicker.hexLabel.text!
        print(appDelegate3.colorValue)
        
        
      
        
        coreDate()
        
     
        let highlighter = CTDynamicGlowHighlighter()
        highlighter.highlightColor = color
        highlighter.animDuration = 0.5
        highlighter.glowSize = 5
        highlighter.maxOffset = 10
        
        showcase.highlighter = highlighter
        showcase.setup(for: lightRayView)
        showcase.show()
        
        //Perform zesty animation
        UIView.animate(withDuration: 0.2,
                       animations: {
                        self.lightRayView.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
        }, completion: { (done) in
            UIView.animate(withDuration: 0.2, animations: {
                self.lightRayView.transform = CGAffineTransform.identity
            })
        })
    }
}
extension UIColor{
    func HexToColor(hexString: String, alpha:CGFloat? = 1.0) -> UIColor {
        // Convert hex string to an integer
        let hexint = Int(self.intFromHexString(hexStr: hexString))
        let red = CGFloat((hexint & 0xff0000) >> 16) / 255.0
        let green = CGFloat((hexint & 0xff00) >> 8) / 255.0
        let blue = CGFloat((hexint & 0xff) >> 0) / 255.0
        let alpha = alpha!
        // Create color object, specifying alpha as well
        let color = UIColor(red: red, green: green, blue: blue, alpha: alpha)
        return color
    }
    
    func intFromHexString(hexStr: String) -> UInt32 {
        var hexInt: UInt32 = 0
        // Create scanner
        let scanner: Scanner = Scanner(string: hexStr)
        // Tell scanner to skip the # character
        scanner.charactersToBeSkipped = NSCharacterSet(charactersIn: "#") as CharacterSet
        // Scan hex value
        scanner.scanHexInt32(&hexInt)
        return hexInt
    }
}
